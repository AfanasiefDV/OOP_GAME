#include "EasyRules.h"
EasyRules::EasyRules() {}
unsigned int EasyRules::getCountEnemy() {
	return this->countEnemy;
}
unsigned int EasyRules::getCountItem() {
	return this->countItem;
}
unsigned int EasyRules::getRuleEndGame() {
	return this->endGame;
}