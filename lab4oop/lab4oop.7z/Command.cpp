#include "Command.h"
sf::Keyboard::Key Command::checkLeft() {
	return sf::Keyboard::Left;
}
sf::Keyboard::Key Command::checkUp() {
	return sf::Keyboard::Up;
}
sf::Keyboard::Key Command::checkDown() {
	return sf::Keyboard::Down;
}
sf::Keyboard::Key Command::checkRight() {
	return sf::Keyboard::Right;
}
sf::Keyboard::Key Command::checkEnter() {
	return sf::Keyboard::Enter;
}
sf::Keyboard::Key Command::checkSave() {
	return sf::Keyboard::S;
}
sf::Keyboard::Key Command::checkLoad() {
	return sf::Keyboard::L;
}