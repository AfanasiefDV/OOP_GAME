#include "HardRules.h"
HardRules::HardRules(){}
unsigned int HardRules::getCountEnemy() {
	return this->countEnemy;
}
unsigned int HardRules::getCountItem() {
	return this->countItem;
}
unsigned int HardRules::getRuleEndGame() {
	return this->endGame;
}
