#include "Controller.h"

int main() {
	Controller<EasyRules> controller;
	controller.start();
    return 0;
}