#include "AverageRules.h"
AverageRules::AverageRules() {}
unsigned int AverageRules::getCountEnemy() {
	return this->countEnemy;
}
unsigned int AverageRules::getCountItem() {
	return this->countItem;
}
unsigned int AverageRules::getRuleEndGame() {
	return this->endGame;
}